# Criação de um projeto JAVA com acesso à base de dados mysql
Trabalho da disciplina de Projetos para Web. Projeto desenvolvido pela aluna Emanuela de Almeida Silva do 3º ano C.
![image](https://user-images.githubusercontent.com/64985077/130098660-315c0a25-2a17-4498-9819-abc2554a9779.png)
